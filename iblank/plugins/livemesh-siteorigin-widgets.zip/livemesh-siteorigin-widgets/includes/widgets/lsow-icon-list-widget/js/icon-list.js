jQuery(function ($) {


    $('.lsow-icon-list .lsow-icon-list-item').powerTip({
        placement: 'n' // north-east tooltip position
    });


});