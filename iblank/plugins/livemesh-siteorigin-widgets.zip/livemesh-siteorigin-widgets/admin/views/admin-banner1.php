<?php

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

?>

<div id="lsow-banner-wrap">

    <div id="lsow-banner" class="lsow-banner-sticky">
        <h2><span><?php echo __('Livemesh SiteOrigin Widgets', 'livemesh-so-widgets'); ?></span><?php echo __('Plugin Documentation', 'livemesh-so-widgets') ?></h2>
    </div>

</div>