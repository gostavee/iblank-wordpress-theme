<?php

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

?>

    <div id="lsow-infobox">
        <div class="lsow-info-overlay"></div>
        <div class="lsow-info-inner">
            <div class="lsow-infobox-msg"></div>
        </div>
    </div>

</div><!-- lsow-wrap -->