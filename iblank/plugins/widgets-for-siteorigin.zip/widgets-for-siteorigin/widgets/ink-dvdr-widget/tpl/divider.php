<div class="iw-so-divider-top"></div>
<div class="iw-so-divider <?php echo $class_divider ?>"></div>
<div class="iw-so-divider-bottom"></div>
