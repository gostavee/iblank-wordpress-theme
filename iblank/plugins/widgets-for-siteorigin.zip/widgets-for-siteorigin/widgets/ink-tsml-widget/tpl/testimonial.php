<?php wpinked_so_testimonial_template( $instance['name'], $instance['testimonial'], $instance['styling'] ); ?>
