<?php wpinked_so_person_template( $instance['name'], $instance['person'], $instance['social'], $instance['styling'] ); ?>
